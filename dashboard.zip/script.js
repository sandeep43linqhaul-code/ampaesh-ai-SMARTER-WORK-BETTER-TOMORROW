// Logout Functionality
function handleLogout() {
    let confirmLogout = confirm("Kya aap sach mein logout karna chahte hain?");
    if (confirmLogout) {
        // Session clear karein agar use kiya ho
        localStorage.clear();
        sessionStorage.clear();
        
        // Login page par redirect karein (apne login page ka naam yahan likhein, jaise index.html ya login.html)
        window.location.href = "index.html";
    }
}